package main

import (
	"fmt"
	"net/http"
)

func main() {
	// 简单的代理逻辑，后续会替换为动态路由
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintf(w, "Welcome to the API Gateway!")
	})

	fmt.Println("API Gateway starting on port 8080...")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		panic(err)
	}
}
