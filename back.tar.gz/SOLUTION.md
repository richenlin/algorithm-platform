# 算法管理与调度平台解决方案

## 1. 概述

本文档旨在设计一个功能全面的算法管理平台，该平台支持多种开发语言，集成在线开发、自动化镜像构建、多模式运行调度等核心功能。平台以Docker容器为基础，通过**Docker Compose**进行服务编排与管理，旨在为算法开发者和使用者在**资源有限的环境**下，提供一个标准化、高效、安全、可扩展的算法即服务（Algorithm-as-a-Service）环境。

## 2. 核心架构设计

平台采用微服务架构，各模块职责分明，通过API进行通信，并统一由`Docker Compose`进行管理。

```mermaid
graph TD
    subgraph User/Client
        A[用户UI / Frontend]
        B[外部调用方 / External API Caller]
    end

    subgraph Platform Services (Docker Compose Managed)
        C[API网关 (自研/Built-in)]
        D[核心服务 (管理/调度/构建)]
        E[在线开发服务 (Online Dev)]
        H[Webhook服务 (Webhook)]
    end

    subgraph Infrastructure
        I[Docker Host]
        J[数据库 (PostgreSQL)]
        K[容器镜像仓库 (Harbor)]
        L[对象存储 (MinIO)]
    end

    A --> C
    B --> C

    C --> D
    C --> E
    
    D <--> J
    D -->|Docker Engine API| I(Build, Run Containers)
    D -->|推送镜像| K
    D --> L
    D --> H

    E -->|Docker Engine API| I(Start/Stop Dev Containers)
    
    H --> B
```

### 架构组件说明

-   **API网关 (自研/Built-in)**：平台统一入口，使用**Golang实现**，负责请求路由、身份认证（Token校验）、限流和日志记录。它取代了外部网关组件，降低了系统复杂性。
-   **核心服务 (管理/调度/构建)**：平台的业务逻辑中心，一个统一的服务包含了三个核心功能：
    -   **算法管理**: 负责维护算法的基本信息、版本、配置等元数据。
    -   **镜像构建**: 根据算法元数据和源代码，动态生成`Dockerfile`并调用Docker Engine API执行构建。
    -   **算法调度**: 接收算法运行请求，并将其转化为对Docker Host的操作（`docker run`或管理`docker-compose`服务）。
-   **在线开发服务 (Online Dev)**：为开发者提供隔离的、安全的在线编码环境。通过直接调用**Docker Engine API**，为每个开发会话启动一个独立的`code-server`容器。
-   **Webhook服务 (Webhook)**：负责在异步任务完成后，将结果状态和数据地址通过HTTP回调通知给调用方。**此功能可作为核心服务的一个模块实现**。
-   **Docker Host**: 运行Docker守护进程的物理机或虚拟机，负责所有容器的生命周期管理。所有平台服务和算法都将作为容器在此主机上运行。
-   **数据库 (PostgreSQL)**：存储所有结构化数据，如算法元数据、用户信息、任务队列、运行日志等。
-   **容器镜像仓库 (Harbor)**：存储所有构建好的算法镜像，并提供权限控制和安全扫描。
-   **对象存储 (MinIO)**：用于存储算法的输入/输出数据、中间结果以及结果缓存。

## 3. 模块功能详述

### 3.1. 算法管理与维护

-   **前端界面**：提供可视化的表单，用于创建和编辑算法。
-   **核心字段**：
    -   `算法名称/ID`：唯一标识。
    -   `算法描述`：功能说明。
    -   `标签`：便于分类和搜索。
    -   `算法语言`：下拉选择（Python, MATLAB, C++, Binary），此选项决定了构建时使用的基础镜像。
    -   `运行平台`：多选（X86, ARM），决定了需要构建的镜像架构。
    -   `源码/文件`：支持直接上传源码压缩包/可执行文件。
    -   `输入目录`：容器内的数据输入路径，例如 `/alg/input`。
    -   `输出目录`：容器内的数据输出路径，例如 `/alg/output`。
-   **后端逻辑**：服务将这些元数据存入数据库。当用户上传文件时，文件被存入与该算法版本关联的MinIO存储桶中。

### 3.2. 算法在线开发 (VSCode Server)

-   **触发**：用户在UI上点击“在线开发”按钮。
-   **流程**：
    1.  在线开发服务收到请求，通过调用**Docker Engine API**（例如使用Docker SDK for Go），为用户和算法创建一个专用的`code-server`容器。
    2.  通过**bind mount** (`-v`参数)将宿主机上该算法的源码目录挂载到容器中，实现代码的持久化。
    3.  **自研API网关**提供一个带认证的代理路由，将用户的WebSocket和HTTP请求安全地转发到对应的`code-server`容器的端口上。
-   **安全性设计**：
    -   **网络隔离**：`code-server`容器可以加入自定义的Docker bridge network，通过Docker的网络规则限制其访问范围。
    -   **用户隔离**：容器内以非root用户身份运行`code-server`。
    -   **资源限制**：在启动容器时，通过`docker run`的参数（如`--memory`, `--cpus`）设置资源限制，防止资源滥用。
    -   **安全代理**：用户不直接访问`code-server`的端口，所有流量经过**API网关**进行认证和审计。

### 3.3. 算法镜像构建

-   **构建源**：支持源码（Python, MATLAB, C++）和预编译的可执行文件（Binary）。
-   **流程**：
    1.  用户在UI上为某个算法版本点击“构建镜像”。
    2.  **核心服务**根据算法语言，选择对应的基础镜像模板。
        -   `Python`: `python:3.9-slim`
        -   `C++`: `gcc:latest` (作为多阶段构建的第一阶段)
        -   `MATLAB`: 需要包含MATLAB Runtime的基础镜像。
        -   `Binary`: `ubuntu:20.04` 或更精简的 `gcr.io/distroless/static-debian11`。
    3.  **动态生成Dockerfile**：
        ```dockerfile
        # Base Image (Dynamically selected)
        FROM python:3.9-slim AS base
        
        # Set non-root user
        RUN useradd -ms /bin/bash user
        USER user
        WORKDIR /home/user/app
        
        # Copy source code
        COPY --chown=user:user . .
        
        # Install dependencies (If source code type)
        RUN pip install -r requirements.txt
        
        # Set entrypoint (Dynamically set)
        # Example for Python
        ENTRYPOINT ["python", "main.py"] 
        # Example for Binary
        # ENTRYPOINT ["/home/user/app/my_executable"]
        ```
    4.  **执行构建**：**核心服务**通过挂载宿主机的`docker.sock` (`-v /var/run/docker.sock:/var/run/docker.sock`)来获得Docker守护进程的控制权，然后执行`docker build`和`docker push`命令。支持`--platform linux/amd64,linux/arm64`参数构建多平台镜像。
    5.  构建成功后，将镜像地址（如 `harbor.mycompany.com/algorithms/my-alg:v1.2.0`）更新到算法版本的元数据中。

### 3.4. 算法运行调度

#### 3.4.1. 异步运算（计划任务/一次性）

-   **API调用触发**：外部系统通过统一API发起调用。
-   **调度流程**：
    1.  **核心服务**验证请求，生成一个唯一的`task_id`。
    2.  创建`alg.json`文件，包含调用参数、数据源文件名、结果文件名和Webhook地址，并将其上传到MinIO，或保存在宿主机临时目录。
    3.  **通过Docker SDK或命令行执行 `docker run` 命令启动一个一次性容器。**
    4.  **`docker run` 参数配置**：
        -   `--rm`: 任务结束后自动删除容器。
        -   `image`: 指定算法镜像。
        -   `command`: `["--alg-json", "/alg/config/alg.json"]`。
        -   `--mount` 或 `-v`:
            -   将宿主机上的`alg.json`文件挂载到容器的 `/alg/config`。
            -   将宿主机上的输入数据目录挂载到容器的`input`目录 (`/alg/input`)。
            -   将宿主机上的输出目录挂载到容器的`output`目录 (`/alg/output`)。
    5.  容器启动后，算法程序读取`/alg/config/json`，从输入目录读取数据，计算后将结果写入输出目录。
    6.  **核心服务**通过`docker wait`或轮询容器状态，监听到容器成功退出后，读取宿主机输出目录中的文件，上传回MinIO。
    7.  触发Webhook服务（或核心服务内的Webhook模块），向调用方发送通知。
-   **计划任务**：对于周期性任务，**核心服务**内部可以集成一个cron库（如`robfig/cron` for Go），定时触发上述`docker run`流程。

#### 3.4.2. 实时运算（常驻服务）

-   **API或UI触发**：用户选择“实时运算”模式并启动。
-   **调度流程**：
    1.  **核心服务**动态地修改`docker-compose.yml`文件（或一个独立的`docker-compose.realtime.yml`），添加或更新该算法的服务定义。
    2.  **服务定义示例**：
        ```yaml
        services:
          my-realtime-algorithm:
            image: harbor.mycompany.com/algorithms/my-alg:v1.2.0
            command: # 启动一个轻量级Web服务器，如Flask/FastAPI
            networks:
              - platform-network
        ```
    3.  **核心服务**执行`docker-compose -f ... up -d my-realtime-algorithm`来启动或更新该算法服务。
    4.  自研API网关动态加载路由规则（例如从数据库或配置文件中读取），将指向该算法ID的实时调用请求 (`/api/v1/run/realtime/{algorithm_id}`) 代理到其对应的容器名称和端口（例如`my-realtime-algorithm:8000`）。
    5.  调用方发起的实时请求，负载会直接转发到常驻的算法容器中，容器处理后立即返回结果。

## 4. 统一算法调用API设计

-   **Endpoint**: `POST /api/v1/run`
-   **Authentication**: `Authorization: Bearer <YOUR_TOKEN>`
-   **Request Body**:
    ```json
    {
      "algorithm_id": "string", // 必填，算法的唯一ID
      "mode": "async" | "realtime", // 必填，调用方式
      "parameters": { // 算法的业务参数，将原样注入到alg.json中
        "input_files": ["data1.csv", "config.json"], // 指定输入文件名
        "output_file": "result.txt", // 指定输出文件名
        "threshold": 0.85,
        "...": "..."
      },
      "webhook_url": "https://my-service.com/callback" // 异步模式必填
    }
    ```
-   **Response (Async)**:
    ```json
    {
      "status": "submitted",
      "task_id": "uuid-v4-string" // 用于后续查询任务状态
    }
    ```
-   **Response (Realtime)**: 直接返回算法的计算结果，格式由算法本身定义。
    ```json
    {
      "result": "...",
      "confidence": 0.98
    }
    ```

## 5. 技术选型建议

-   **前端**: Vue.js
-   **后端服务**: Golang 
-   **API网关**: Golang (自研)
-   **数据库**: PostgreSQL
-   **容器编排**: Docker Compose
-   **CI/CD (镜像构建)**: Docker Build
-   **容器镜像仓库**: Harbor
-   **对象存储**: MinIO
-   **在线开发环境**: Code-Server
